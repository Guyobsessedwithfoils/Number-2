# Number-2 Mobile FPS

A simple first-person 3D browser game made with Three.js.

## Controls

### Mobile
- Left joystick: move
- Drag the right side: look around
- JUMP button: jump

### Desktop
- WASD / arrow keys: move
- Mouse: look
- Space: jump

## Run

This is a static website. You can open `index.html` in a browser, or host the repository with GitHub Pages.

Three.js is loaded from a CDN, so the browser needs internet access.
