import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.161.0/build/three.module.js";

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87b7d8);
scene.fog = new THREE.Fog(0x87b7d8, 35, 180);

const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.05,
  250
);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
document.getElementById("game").appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xffffff, 0x52616b, 2.2));

const sun = new THREE.DirectionalLight(0xffffff, 2.2);
sun.position.set(20, 35, 10);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
scene.add(sun);

// Ground
const ground = new THREE.Mesh(
  new THREE.BoxGeometry(180, 1, 180),
  new THREE.MeshStandardMaterial({ color: 0x4d6847, roughness: 1 })
);
ground.position.y = -0.5;
ground.receiveShadow = true;
scene.add(ground);

// Simple arena walls
const wallMaterial = new THREE.MeshStandardMaterial({ color: 0x69747a });
function addBox(x, y, z, w, h, d, color = null) {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, d),
    new THREE.MeshStandardMaterial({
      color: color ?? 0x8a8f91,
      roughness: .9
    })
  );
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  scene.add(mesh);
  obstacles.push({
    minX: x - w / 2, maxX: x + w / 2,
    minY: y - h / 2, maxY: y + h / 2,
    minZ: z - d / 2, maxZ: z + d / 2
  });
}

const obstacles = [];
addBox(0, 2, -20, 42, 4, 2, 0x777b7d);
addBox(-21, 2, 0, 2, 4, 42, 0x777b7d);
addBox(21, 2, 0, 2, 4, 42, 0x777b7d);

// Cover / obstacles
addBox(-8, 1.5, -8, 5, 3, 5, 0x9a825f);
addBox(7, 1, -5, 4, 2, 7, 0x6d7780);
addBox(2, 2, 7, 7, 4, 3, 0x8c765d);
addBox(-10, 1, 9, 3, 2, 6, 0x6d7780);
addBox(11, 1.5, 12, 5, 3, 5, 0x9a825f);

// Player
const player = {
  pos: new THREE.Vector3(0, 1.7, 14),
  velocityY: 0,
  radius: 0.35,
  height: 1.7,
  grounded: true
};

camera.position.copy(player.pos);

let yaw = 0;
let pitch = 0;

const keys = new Set();
window.addEventListener("keydown", e => {
  keys.add(e.code);
  if (e.code === "Space") e.preventDefault();
});
window.addEventListener("keyup", e => keys.delete(e.code));

let pointerLocked = false;
renderer.domElement.addEventListener("click", () => {
  if (window.innerWidth >= 800) renderer.domElement.requestPointerLock?.();
});

document.addEventListener("pointerlockchange", () => {
  pointerLocked = document.pointerLockElement === renderer.domElement;
});

document.addEventListener("mousemove", e => {
  if (!pointerLocked) return;
  yaw -= e.movementX * 0.0025;
  pitch -= e.movementY * 0.0025;
  pitch = THREE.MathUtils.clamp(pitch, -1.45, 1.45);
});

// Mobile joystick
const joystick = document.getElementById("joystick");
const stick = document.getElementById("stick");
let joyPointer = null;
let joyX = 0;
let joyY = 0;

function updateJoystick(clientX, clientY) {
  const r = joystick.getBoundingClientRect();
  const cx = r.left + r.width / 2;
  const cy = r.top + r.height / 2;
  const dx = clientX - cx;
  const dy = clientY - cy;
  const max = r.width * 0.30;
  const len = Math.hypot(dx, dy);
  const scale = len > max ? max / len : 1;
  const x = dx * scale;
  const y = dy * scale;
  stick.style.transform = `translate(${x}px, ${y}px)`;
  joyX = x / max;
  joyY = y / max;
}

joystick.addEventListener("pointerdown", e => {
  joyPointer = e.pointerId;
  joystick.setPointerCapture(e.pointerId);
  updateJoystick(e.clientX, e.clientY);
});

joystick.addEventListener("pointermove", e => {
  if (e.pointerId === joyPointer) updateJoystick(e.clientX, e.clientY);
});

function resetJoystick(e) {
  if (e.pointerId !== joyPointer) return;
  joyPointer = null;
  joyX = joyY = 0;
  stick.style.transform = "";
}
joystick.addEventListener("pointerup", resetJoystick);
joystick.addEventListener("pointercancel", resetJoystick);

// Mobile camera look
const lookArea = document.getElementById("lookArea");
let lookPointer = null;
let lastLookX = 0;
let lastLookY = 0;

lookArea.addEventListener("pointerdown", e => {
  lookPointer = e.pointerId;
  lastLookX = e.clientX;
  lastLookY = e.clientY;
  lookArea.setPointerCapture(e.pointerId);
});

lookArea.addEventListener("pointermove", e => {
  if (e.pointerId !== lookPointer) return;
  const dx = e.clientX - lastLookX;
  const dy = e.clientY - lastLookY;
  lastLookX = e.clientX;
  lastLookY = e.clientY;

  yaw -= dx * 0.008;
  pitch -= dy * 0.008;
  pitch = THREE.MathUtils.clamp(pitch, -1.45, 1.45);
});

function endLook(e) {
  if (e.pointerId === lookPointer) lookPointer = null;
}
lookArea.addEventListener("pointerup", endLook);
lookArea.addEventListener("pointercancel", endLook);

// Jump
function jump() {
  if (player.grounded) {
    player.velocityY = 7.2;
    player.grounded = false;
  }
}
document.getElementById("jump").addEventListener("pointerdown", e => {
  e.preventDefault();
  jump();
});
window.addEventListener("keydown", e => {
  if (e.code === "Space") jump();
});

function collides(pos) {
  const r = player.radius;
  const feet = pos.y - player.height;
  const head = pos.y;

  for (const o of obstacles) {
    if (head < o.minY || feet > o.maxY) continue;
    if (
      pos.x + r > o.minX && pos.x - r < o.maxX &&
      pos.z + r > o.minZ && pos.z - r < o.maxZ
    ) return true;
  }
  return false;
}

function tryMove(dx, dz) {
  const nextX = player.pos.clone();
  nextX.x += dx;
  if (!collides(nextX)) player.pos.x = nextX.x;

  const nextZ = player.pos.clone();
  nextZ.z += dz;
  if (!collides(nextZ)) player.pos.z = nextZ.z;
}

const clock = new THREE.Clock();

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);

  // Movement direction relative to camera yaw
  let forward = 0;
  let strafe = 0;

  if (keys.has("KeyW") || keys.has("ArrowUp")) forward += 1;
  if (keys.has("KeyS") || keys.has("ArrowDown")) forward -= 1;
  if (keys.has("KeyD") || keys.has("ArrowRight")) strafe += 1;
  if (keys.has("KeyA") || keys.has("ArrowLeft")) strafe -= 1;

  forward += -joyY;
  strafe += joyX;

  const len = Math.hypot(forward, strafe);
  if (len > 1) {
    forward /= len;
    strafe /= len;
  }

  const speed = 6.5;
  const sin = Math.sin(yaw);
  const cos = Math.cos(yaw);

  const dx = (strafe * cos + forward * sin) * speed * dt;
  const dz = (strafe * -sin + forward * cos) * speed * dt;
  tryMove(dx, dz);

  // Gravity
  player.velocityY -= 20 * dt;
  player.pos.y += player.velocityY * dt;

  if (player.pos.y <= player.height) {
    player.pos.y = player.height;
    player.velocityY = 0;
    player.grounded = true;
  }

  camera.position.copy(player.pos);
  camera.rotation.order = "YXZ";
  camera.rotation.y = yaw;
  camera.rotation.x = pitch;

  renderer.render(scene, camera);
}

window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

animate();
